const player1 = 1;
const player2 = 2;
var playTime = Math.round(Math.random()*2);
var gameOver = false;


atualizaMostrador();
inicializarEspacos();

function atualizaMostrador(){

    if (gameOver) { return;}

    if (playTime == player1) {

        var player = document.querySelectorAll("div#mostrador img")[0];
        player.setAttribute("src","images/x.png");

    } else{

    	var player = document.querySelectorAll("div#mostrador img")[0];
    	player.setAttribute("src","images/o.png");

    }

}

function inicializarEspacos(){

    var espacos = document.getElementsByClassName("espaco");
    for (var i = 0; i < espacos.length; i++) {

        espacos[i].addEventListener("click", function(){


          if (gameOver) {return;}

          if (this.getElementsByTagName("img").length == 0){

              if (playTime == player1) {

                this.innerHTML = "<img src='images/x.png' height='50px;' length='50px;'>";
                this.setAttribute("jogada", player1);
                playTime = player2;

              } else {

                this.innerHTML = "<img src='images/o.png' height='50px;' length='50px;'>";
                this.setAttribute("jogada", player2);
                playTime = player1;

              }
              atualizaMostrador();
              verificarVencedor();
            }
          });
      }
}

function verificarVencedor(){

var a1 = document.getElementById("a1").getAttribute("jogada");
var a2 = document.getElementById("a2").getAttribute("jogada");
var a3 = document.getElementById("a3").getAttribute("jogada");
var a4 = document.getElementById("a4").getAttribute("jogada");
var a5 = document.getElementById("a5").getAttribute("jogada");

var b1 = document.getElementById("b1").getAttribute("jogada");
var b2 = document.getElementById("b2").getAttribute("jogada");  
var b3 = document.getElementById("b3").getAttribute("jogada");
var b4 = document.getElementById("b4").getAttribute("jogada");
var b5 = document.getElementById("b5").getAttribute("jogada");

var c1 = document.getElementById("c1").getAttribute("jogada");
var c2 = document.getElementById("c2").getAttribute("jogada");
var c3 = document.getElementById("c3").getAttribute("jogada");
var c4 = document.getElementById("c4").getAttribute("jogada");
var c5 = document.getElementById("c5").getAttribute("jogada");

var d1 = document.getElementById("d1").getAttribute("jogada");
var d2 = document.getElementById("d2").getAttribute("jogada");
var d3 = document.getElementById("d3").getAttribute("jogada");
var d4 = document.getElementById("d4").getAttribute("jogada");
var d5 = document.getElementById("d5").getAttribute("jogada");

var e1 = document.getElementById("e1").getAttribute("jogada");
var e2 = document.getElementById("e2").getAttribute("jogada");
var e3 = document.getElementById("e3").getAttribute("jogada");
var e4 = document.getElementById("e4").getAttribute("jogada");
var e5 = document.getElementById("e5").getAttribute("jogada");

var vencedor = "";


if (((a1 == b1 && a1 == c1 && a1 == d1 && a1 == e1) || (a1 == a2 && a1 == a3 && a1 == a4 && a1 == a5) || (a1 == b2 && a1 == c3 && a1 == d4 && a1 == e5)) && a1 != "") {
  vencedor = a1;
} else if(((b2 == b1 && b2 == b3 && b2 == b4 && b2 == b5)||(b2 == a2 && b2 == c2 && b2 == d2 && b2 == e2) || (b2 == a1 && b2 == c3 && b2 == d4 && b2 == e5)) && b2 != "") {
  vencedor = b2;
} else if(((c3 == c1 && c3 == c2 && c3 == c4 && c3 == c5)||(c3 == b3 && c3 == a3 && c3 == d3 && c3 == e3) || (c3 == d4 && c3 == e5 && c3 == b2 && c3 == a1) || (c3 == b4 && c3 == a5 && c3 == d2 && c3 == e1)) && c3 != ""){
  vencedor = c3;
} else if (((d4 == e4 && d4 == c4 && d4 == b4 && d4 == a4) || (d4 == d5 && d4 == d3 && d4 == d2 && d4 == d1) || (d4 == e5 && d4 == c3 && d4 == b2 && d4 == a1)) && d4 != "") {
  vencedor = d4;
} else if (((e5 == a5 && e5 == b5 && e5 == c5 && e5 == d5) || (e5 == e1 && e5 == e2 && e5 == e3 && e5 == e4) || (e5 == b2 && e5 == c3 && e5 == d4 && e5 == a1)) && e5 != "") {
  vencedor = e5;
}

if (vencedor != "") {
	if (vencedor == 1) {
    vencedor = 'X';
    gameOver = true;
    alert("O ganhador foi o: '" + vencedor + "'");
} else {
	vencedor = 'O';
    gameOver = true;
    alert("O ganhador foi o: '" + vencedor + "'");
}
}
}